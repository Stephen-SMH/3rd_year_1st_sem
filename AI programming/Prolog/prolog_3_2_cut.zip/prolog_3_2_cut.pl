has_factor2(N,K) :-
	K * K =< N,
	V is N mod K,
	0  == V.
has_factor2(N,K) :-
	K * K =< N,
	K1 is K + 1,
	has_factor2(N,K1).
is_prime2(2):-!.
is_prime2(N) :-
	\+ has_factor2(N,2).